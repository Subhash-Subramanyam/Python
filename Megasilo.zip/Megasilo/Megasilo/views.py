from django.http import HttpResponse
from django.template import loader 
from django.shortcuts import render  
from django.db import models
from django.db import connections
import json

def procModel(request):
  
  try:
      data = []
      intVal = 1
      cursor = connections['default'].cursor()
      cursor.execute('EXEC support.uspFetchSomeData %s' , [intVal])
      
      rows = cursor.fetchall()

      for row in rows:
        data.append(list(row))
      
      print(data)

  finally:
      cursor.close()

  # template = loader.get_template('procTest.html') 
  CaseCat=[]
  metricsDict = {'metricsValue' : data }
  CaseCat.append(metricsDict)
  
  jsonData=json.dumps(CaseCat)
  return HttpResponse(jsonData, content_type='application/json')