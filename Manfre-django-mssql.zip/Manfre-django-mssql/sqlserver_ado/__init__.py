from __future__ import absolute_import, unicode_literals
# following PEP 386
__version__ = "1.8"

from . import patches  # NOQA
from . import expressions  # NOQA
