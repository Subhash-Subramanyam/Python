Project is not actively maintained. 

Microsoft's employees that maintain the SQL drivers recommend against using the 
COM subsystems, which are used by django-mssql. Microsoft's ODBC drivers are much
better. 

An actively maintained alternative for 
accessing SQL Server is django-pyodbc-azure_.

Django MSSQL Database Backend
=============================

`Django-mssql`_ provies a Django database backend for Microsoft SQL Server.

Documentation is available at `django-mssql.readthedocs.org`_.

Requirements
------------

    * Python 2.7, 3.4
    * PyWin32_
    * SQL Server Management Studio or Microsoft Data Access Components (MDAC)

SQL Server Versions
-------------------

Supported Versions:
    * 2012

SQL 2008/2008r2 are support by django-mssql 1.6.x.

Django Version
--------------

	* Django 1.8

django-mssql 1.7 supports Django 1.7.
django-mssql 1.6 supports Django 1.6.
django-mssql 1.4 supports Django 1.4 and 1.5.


References
----------

    * Django-mssql on PyPi: http://pypi.python.org/pypi/django-mssql
    * DB-API 2.0 specification: http://www.python.org/dev/peps/pep-0249/


.. _`Django-mssql`: https://bitbucket.org/Manfre/django-mssql
.. _django-mssql.readthedocs.org: https://django-mssql.readthedocs.io/
.. _PyWin32: http://sourceforge.net/projects/pywin32/
.. _django-pyodbc-azure: https://pypi.org/project/django-pyodbc-azure/