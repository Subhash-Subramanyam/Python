import unicodecsv
import sys
import os
import time
import urllib
from urllib.parse import urlparse
import glob
import pandas as pd
from salesforce_bulk import SalesforceBulk
from salesforce_bulk import CsvDictsAdapter
import requests

def DumpSfdcQueryResultsToCsv(Query, Object, OutfileCsv):
    try:
        # Salesforce Credentials
        sfusername = 'tableau@mitel.com'                #config.get('Section', 'username')
        sfpassword = 'Morty92!G'                        #config.get('Section', 'password')
        sfsecuritytoken = '8gCeBZuVJW92LfWXfq8th5xP'    #config.get('Section', 'security_token')
        sfOrganizationId = '00Dd0000000eyog'

        # bulk = SalesforceBulk(host=urlparse('https://mitel.my.salesforce.com/').hostname, username=sfusername, password=sfpassword, API_version= '49.0', security_token=sfsecuritytoken)
        bulk = SalesforceBulk(username=sfusername, password=sfpassword, API_version='49.0', security_token=sfsecuritytoken, organizationId=sfOrganizationId)
        job = bulk.create_query_job(Object, contentType='CSV')
        batch = bulk.query(job, Query)
        bulk.close_job(job)
        
        while not bulk.is_batch_done(batch):
            time.sleep(6)

        for result in bulk.get_all_results_for_query_batch(batch):
            reader = unicodecsv.DictReader(result, encoding='utf-8')

        df = pd.DataFrame(reader)
        df.to_csv(OutfileCsv)

    except Exception as e:
        print ("Exception occurred: <%s>"%e)
        print ("Reconnecting to Salesforce")
       
    