import Settings as St 
import os

BlueSfdcList = [
["SELECT Id, Name, CreatedDate, CreatedById, Risk_Category__c, CustomerType__c, Platform__c, Status__c, Type, Customer_Since__c, Email__c, End_Points__c, RecordTypeId FROM Account WHERE CreatedDate >= 2020-01-01T00:00:00Z", "Account", "Blue_Account.csv"]
,["SELECT AccountId,Business_Impact__c,Business_Owner__c,CaseNumber,Category__c,ClosedDate,Comments,Community_Cloud__c,ContactEmail,ContactFax,ContactId,ContactMobile,ContactPhone,CreatedById,CreatedDate,CurrencyIsoCode,Data_Quality_Description__c,Data_Quality_Score__c,Date_Identified__c,Date_Requested_By__c,Deployment_Status__c,Description,Employee_ID__c,Environment__c,Global_Picklist_Field__c,HasCommentsUnreadByOwner,HasSelfServiceComments,Hire_Date__c,Id,Impact_To__c,Instance__c,IsClosed,IsDeleted,ITA__c,Jira__c,Language,LastModifiedById,LastModifiedDate,LastReferencedDate,LastViewedDate,Level__c,Login_URL__c,MasterRecordId,Members__c,Object_s_Involved__c,Origin,OwnerId,ParentId,Percent_Complete__c,Previous_UAT_Defect_ID__c,Priority,RecordTypeId,Reference_Code__c,Reference_User__c,Reporting_Status__c,Requirement_Type__c,Resolution__c,Sales_Cloud__c,Short_Description__c,SIR__c,SourceId,Status,ST_DEVELOP__c,ST_PROD__c,ST_UAT__c,Subject,SystemModstamp,Target_Deployment_Date__c,Target_UAT_Completion__c,TempOwnerId__c,Title__c,Type,Username__c,User_Created__c,User_Email__c,User_First_Name__c,User_Last_Name__c,User_Manager__c,User_Request_Type__c,Week_Ending_Date__c,Work_Required__c FROM Case WHERE CreatedDate >= 2020-03-01T00:00:00Z", "Case", "Blue_Case.csv"]
,["SELECT Id,ParentId,CreatedById,CreatedDate,IsDeleted,IsPublished,IsNotificationSelected,LastModifiedById,LastModifiedDate  FROM CaseComment WHERE CreatedDate >= 2020-06-01T00:00:00Z LIMIT 100000", "CaseComment", "Blue_CaseComment.csv"]
,["SELECT Id,CaseId,CompletionDate,IsCompleted,IsDeleted,IsViolated,MilestoneTypeId,TargetDate,TargetResponseInHrs,TimeRemainingInHrs,TimeSinceTargetInHrs,CreatedById,CreatedDate,LastModifiedById,LastModifiedDate FROM CaseMilestone WHERE CreatedDate >= 2020-06-01T00:00:00Z LIMIT 100000", "CaseMilestone", "Blue_CaseMilestone.csv"]
,["SELECT Id,ParentId,ActivityId,FromName,HasAttachment,Incoming,IsExternallyVisible,IsDeleted,CreatedById,CreatedDate,LastModifiedById,LastModifiedDate,MessageDate,RelatedToId,Status,Subject,FromAddress,ToAddress,CcAddress FROM EmailMessage WHERE CreatedDate >= 2020-06-01T00:00:00Z LIMIT 100000", "EmailMessage", "Blue_EmailMessage.csv"]
,["SELECT Id,Abandoned,AccountId,AverageResponseTimeOperator,AverageResponseTimeVisitor,CaseId,ChatDuration,ChatKey,ContactId,CreatedById,CreatedDate,EndedBy,EndTime,IsChatbotSession,IsDeleted,LastModifiedById,LastModifiedDate,LastReferencedDate,LastViewedDate,LeadId,LiveChatButtonId,LiveChatDeploymentId,LiveChatVisitorId,Location,MaxResponseTimeOperator,MaxResponseTimeVisitor,Name,OperatorMessageCount,OwnerId,RequestTime,SkillId,StartTime,Status,VisitorMessageCount,WaitTime  FROM LiveChatTranscript WHERE CreatedDate >= 2020-05-01T00:00:00Z LIMIT 100000", "LiveChatTranscript", "Blue_LiveChatTranscript.csv"]
,["SELECT Id,ContactId,IsActive,CreatedDate,Department,Email,FirstName,LastModifiedDate,LastName,Username,Name,Title,UserRoleId,AccountId,ProfileId,Phone,ManagerId,Extension FROM User WHERE CreatedDate >= 2020-01-01T00:00:00Z", "User", "Blue_User.csv"]
]

for sublist in BlueSfdcList:
    Query = sublist[0] # SOQL Query
    Object = sublist[1] # ObjectName
    OutfileCsv = ".\\archive_csv\\" +  sublist[2] # File Path and Name
    if os.path.exists(OutfileCsv):
        os.remove(OutfileCsv)
    St.DumpSfdcQueryResultsToCsv(Query, Object, OutfileCsv)