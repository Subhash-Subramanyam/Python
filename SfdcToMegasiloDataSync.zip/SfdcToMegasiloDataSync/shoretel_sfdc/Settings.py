import pandas as  pd
import pyodbc
from simple_salesforce import Salesforce
#from fast_to_sql import fast_to_sql as fts
import sqlalchemy
from sqlalchemy import create_engine 
import urllib
import json

pd.set_option('display.max_columns', 25)

uname = 'subhash.subramanyam@mitelst.com'
pwd = '0mG@nesha'
token = 'BJPEUEIbzw8LOicB6DscUmfLZ'

# session_id, instance = SalesforceLogin(uname, pwd, security_token = token)
# sf = Salesforce(username='achint.kumar@mitelst.com', password='Feb@2020', security_token='erll36GVA0ugVnIJS4sjenOi')
'''   
def execute_salesforce_queryOrtable(query, tbname):
    sf = Salesforce(username=uname, password=pwd, security_token=token)
    try:
        sf_data = sf.query_all(query)
        #sf_data = sf.bulk.Account.query(soql)
        df = pd.DataFrame(sf_data['records']).drop(columns='attributes')
    except Exception as e:
        print ("Exception occurred: <%s>"%e)
        print ("Reconnecting to Salesforce")
        sf_data = sf.query_all(query)
        df = pd.DataFrame(sf_data['records']).drop(columns='attributes')
    return df

def sqlcol(df):    
    dtypedict = {}
    for i,j in zip(df.columns, df.dtypes):
        if "bigint" in str(j):
            dtypedict.update({i: sqlalchemy.types.BIGINT()})
        if "int" in str(j):
            dtypedict.update({i: sqlalchemy.types.INT()})
        if "object" in str(j):
            dtypedict.update({i: sqlalchemy.types.NVARCHAR(8000)})
        if "datetime" in str(j):
            dtypedict.update({i: sqlalchemy.types.DATETIME()})
    return dtypedict
'''

server = 'svlcorpsilo1.shoretel.com' 
database = 'MEGASILO' 
username = 'ITApps' 
password = '1t@ppm@st3r'


def dump_sfdc_output_to_SqlServer(df, outputdict ):
   
    '''
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cursor = conn.cursor()
    columns = cursor.columns(table='Multiple_Release_Tracking', schema='support').fetchall()
    cursor.execute("INSERT INTO [support].[Multiple_Release_Tracking](attributes) VALUES(?)", )

    insertQuery  = "insert into {0} values ({1})".format(myTable, ','.join('?' * len(columns))

    for key in myDict:
        # build parameter list from individual variable and dictionary values
        params = [key, thisDate] + myDict[key]
        db_cursor.execute(insertQuery, params)
        cnxn.commit()

    '''

    params = urllib.parse.quote_plus('DRIVER={ODBC Driver 17 for SQL Server};'+ 'SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password) 
    engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params) 
    print(pd.io.sql._is_sqlalchemy_connectable(engine))


    # limit based on sp_prepexec parameter count
    tsql_chunksize = 2097 // len(df.columns)
    # cap at 1000 (limit for number of rows inserted by table-value constructor)
    tsql_chunksize = 1000 if tsql_chunksize > 1000 else tsql_chunksize
    print(tsql_chunksize)

    df.to_sql(name = 'Multiple_Release_Tracking', con = engine, schema = 'support', if_exists = 'replace', index= False, chunksize=tsql_chunksize, dtype=outputdict )
    
    