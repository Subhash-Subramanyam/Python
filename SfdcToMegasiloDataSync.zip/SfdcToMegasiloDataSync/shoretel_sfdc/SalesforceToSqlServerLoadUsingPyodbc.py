import unicodecsv
import sys
import os
import time
import pandas as pd
import pyodbc
import urllib
from salesforce_bulk import SalesforceBulk

username = 'subhash.subramanyam@mitelst.com' #config.get('Section', 'username')
password = '0mG@nesha' #config.get('Section', 'password')
security_token = 'BJPEUEIbzw8LOicB6DscUmfLZ' #config.get('Section', 'security_token')
bulk = SalesforceBulk(username=username, password=password, security_token=security_token)

query = "SELECT Defect__r.Name,Name,Status__c,Sub_Status__c,ClosedDate__c,Rejected_Date__c,Rejected_Reason__c,Resolve_Date__c,CreatedDate,Verified_Date__c,Defect__r.Abstract__c,Defect__r.Priority__c,Defect__r.Severity__c,Defect__r.Keywords__c,Defect__r.Defect_Status__c,Defect__r.Found__r.Name,Defect__r.Area__c,Defect__r.Sub_Area__c,Defect__r.Parent_Project__c,Defect__r.Developer__r.Name,Defect__r.Build__r.Name,Defect__r.QA_Owner__r.Name,CreatedBy.Full_Name__c,Defect__r.Field_Issues__c,Defect__r.Found_via__c,Defect__r.CreatedDate,Defect__r.Estimated_Resolution_Date__c,Defect__r.Blocker__c,Defect__r.Blocked__c,Defect__r.Blocked_Reason__c,Defect__r.Number_of_Cases__c,Defect__r.Type__c,Change_List__c,LastModifiedDate,Corrected_in__r.Name,Defect__r.Eng_Group__c,Defect__r.User_StoryID__c,Defect__r.Feature__c,Defect__r.LastModifiedDate,Defect__r.Beta_Blocker__c,Defect__r.Reason__c,Defect__r.Reviewed__c,Defect__r.Deployment_Type__c,PatchedIn__c,Defect__r.Cluster_Information__c FROM Multiple_Release_Tracking__c WHERE (Name LIKE '%Connect%' OR Name LIKE '%Mobility%' OR Name LIKE '%Cosmo%' OR Name LIKE '%Colorado%' OR Name LIKE '%Manhattan%' OR Name LIKE '%BOSS%' OR Name LIKE '%Highball%' OR Name LIKE '%Galileo%' OR Name LIKE '%TBD%' OR Name LIKE '%Link%' OR Name LIKE '%WB.2%' OR Name LIKE '%FRIS%' OR Name LIKE '%Fortuna%' OR Name LIKE '%Brazos%' OR Name LIKE '%IP400RR%' OR Name LIKE '%TwMobile%' OR Name LIKE '%TwWeb%' OR Name LIKE '%TwPlatform%' OR Name LIKE '%UCloud%' OR Name LIKE '%SCC%' OR Name LIKE '%3rd party%')"
# SOQL Query
job = bulk.create_query_job('Multiple_Release_Tracking__c', contentType='CSV')
batch = bulk.query(job, query)
bulk.close_job(job)
while not bulk.is_batch_done(batch):
    time.sleep(6)

for result in bulk.get_all_results_for_query_batch(batch):
    reader = unicodecsv.DictReader(result, encoding='utf-8')
    # for row in reader:
    #    print(row) # dictionary rows

df = pd.DataFrame(reader)
#print(df.info())
#df.to_csv('Multiple_Release_Tracking.csv')

server = 'svlcorpsilo1.shoretel.com' 
database = 'MEGASILO' 
username = 'ITApps' 
password = '1t@ppm@st3r'

#''' Begin of Method 2
# 
conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'+ 'SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
cursor = conn.cursor()
cursor.execute('TRUNCATE TABLE [support].[Multiple_Release_Tracking_Staging_pyodbc]')
cursor.fast_executemany = True
for row_count in range(0, df.shape[0]):
    chunk = df.iloc[row_count:row_count + 1,:].values.tolist()
    tuple_of_tuples = tuple(tuple(x) for x in chunk)
    cursor.executemany("INSERT INTO [support].[Multiple_Release_Tracking_Staging_pyodbc]" + "([Defect__r Name],[Defect__r Abstract__c],[Defect__r Priority__c],[Defect__r Severity__c],[Defect__r Keywords__c],[Defect__r Defect_Status__c],[Defect__r Found__r Name],[Defect__r Area__c],[Defect__r Sub_Area__c],[Defect__r Parent_Project__c],[Defect__r Developer__r Name],[Defect__r Build__r Name],[Defect__r QA_Owner__r Name],[Defect__r Field_Issues__c],[Defect__r Found_via__c],[Defect__r CreatedDate],[Defect__r Estimated_Resolution_Date__c],[Defect__r Blocker__c],[Defect__r Blocked__c],[Defect__r Blocked_Reason__c],[Defect__r Number_of_Cases__c],[Defect__r Type__c],[Defect__r Eng_Group__c],[Defect__r User_StoryID__c],[Defect__r Feature__c],[Defect__r LastModifiedDate],[Defect__r Beta_Blocker__c],[Defect__r Reason__c],[Defect__r Reviewed__c],[Defect__r Deployment_Type__c],[Defect__r Cluster_Information__c],[Name],[Status__c],[Sub_Status__c],[ClosedDate__c],[Rejected_Date__c],[Rejected_Reason__c],[Resolve_Date__c],[CreatedDate],[Verified_Date__c],[CreatedBy Full_Name__c],[Change_List__c],[LastModifiedDate],[Corrected_in__r Name],[PatchedIn__c]) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",tuple_of_tuples)
cursor.commit()
#''' End of Method 2
#'''